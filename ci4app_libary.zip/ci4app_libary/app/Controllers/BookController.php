<?php 

namespace App\Controllers;

use App\Models\logbook;

class BookController extends BaseController
{
    // public function Dashboard(){
    //     return view('Dashboard');
    // }

    // public function Dashboard_penerima(){
    //     return view('Dashboard_Penerima');
    // }

    // public function index(){
    //     $book_model = new logbook();
    //     $all_data_book = $book_model->findAll();
    //     return view('Dashboard', ['all_data_book' => $all_data_book]);
    // }  

    public function Dashboard(){
        // $book_model = new logbook();
        // $all_data_book = $book_model->findAll();
        // return view('Dashboard_Penerima', ['all_data_book' => $all_data_book]);
        return view('Dashboard');
    }
    
    public function Dashboard_Penerima(){
        $book_model = new logbook();
        $all_data_book = $book_model->findAll();
        return view('Dashboard_Penerima', ['all_data_book' => $all_data_book]);
    }
    
    public function Dashboard_Monitoring(){
        $book_model = new logbook();
        $all_data_book = $book_model->findAll();
        return view('Dashboard_Monitoring', ['all_data_book' => $all_data_book]);
    }

    public function form(){
        return view('form');
    }
 
    public function proses() {
        $book_model = new logbook();
        // dd($this->request->getPost());
        $book_model -> insert($this->request->getPost());
        return redirect()->to(base_url('/Dashboard'));
    }

    public function proses_edit_data($id) {
        $book_model = new logbook();
        $book_model->update($id, [
            'nama_pengirim' => $this->request->getPost('nama_pengirim'),
            'perihal' => $this->request->getPost('perihal'),
            'tgl_kirim' => $this->request->getPost('tgl_kirim'),
            'unit_pengirim' => $this->request->getPost('unit_pengirim'),
            'unit_penerima' => $this->request->getPost('unit_penerima'),
            'nama_penerima' => $this->request->getPost('nama_penerima'),
            'tgl_terima' => $this->request->getPost('tgl_terima'),
        ]);
        return redirect()->to(base_url('/Dashboard'));
    }

    // public function book_mentoring($id) {
    //     $book_model = new logbook();
    //     $book_model->update($id, [
    //         'nama_pengirim' => $this->request->getPost('nama_pengirim'),
    //         'perihal' => $this->request->getPost('perihal'),
    //         'tgl_kirim' => $this->request->getPost('tgl_kirim'),
    //         'unit_pengirim' => $this->request->getPost('unit_pengirim'),
    //         'unit_penerima' => $this->request->getPost('unit_penerima'),
    //         'nama_penerima' => $this->request->getPost('nama_penerima'),
    //         'tgl_penerima' => $this->request->getPost('tgl_penerima'),
    //     ]);
    //     return view('book', ['all_data_book' => $all_date_book]);
    // }

    public function edit_data_book($id = false){
        $book_model = new logbook();
        $data_book = $book_model->find($id);
        // dd('edit_data_book' , ['data_book' => $data_book]);
        return view('edit_data_book' , ['data_book' => $data_book]);
    }

    // public function proses_hapus_data($id){
    //     $book_model = new logbook();
    //     $data_book = $book_model->find($id);
    //     return redirect()->to(base_url('/book_mentoring'));
    // }

}

?>