<?php

namespace App\Controllers;

class Home extends BaseController
{

    public function Dashboard()
    {
        return view('Dashboard');
    }

    public function Dashboard_penerima(){
        return view('Dashboard_Penerima');
    }
}
