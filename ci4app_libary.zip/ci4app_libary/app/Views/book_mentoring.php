<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Tabel Mentoring </title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
  </head>
  <body>
    <div class="container">
    <h1>LOGBOOK MENTORING</h1>
    <table class="table">
  <thead>
    <td class="btn btn-primary"><a href="<?= base_url('form') ?>" class="btn btn-primary">Tambah Data</a></td>
    <tr>
      <th scope="col">No</th>
      <th scope="col">Nama Pengirim</th>
      <th scope="col">Perihal</th>
      <th scope="col">Tanggal kirim</th>
      <th scope="col">Unit Pengirim</th>
      <th scope="col">Unit Penerima</th>
      <th scope="col">Nama Penerima</th>
      <th scope="col">Tanggal Terima</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
  <?php
    $no = 1; 
  ?>
        <?php foreach ($all_data_book as $book) : ?>
            <tr>
                <td><?= $no; ?></td>
                <td><?= $book->nama_pengirim ?></td>
                <td><?= $book->perihal ?></td>
                <td><?= $book->tgl_kirim ?></td>
                <td><?= $book->unit_pengirim ?></td>
                <td><?= $book->unit_penerima ?></td>
                <td><?= $book->nama_penerima ?></td>
                <td><?= $book->tgl_terima ?></td>
                <td>
                    <a href="<?= base_url('edit_data_book').'/'. $book->id ?>" class="btn btn-primary btn-sm">Edit </a>
                </td>
            </tr>
        <?php $no++; endforeach ?>
        <br>
        <tr>
          <td>
            <!-- <button class="btn btn-primary"><a href="">Mentoring</a></button> -->
          </td>
          <td>
            <button class="btn btn-primary" onclick="window.print()">Cetak Laporan</button>
        </td>
        </tr>
        <!-- <tr>
          <td><a href="" class="btn btn-secondary">Logout</a></td>
        </tr> -->
  </tbody>
</table>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
  </body>
</html>