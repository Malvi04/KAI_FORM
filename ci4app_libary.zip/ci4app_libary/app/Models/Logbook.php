<?php 

namespace App\Models;

use CodeIgniter\Model;

class logbook extends Model
{
    protected $table = 'data';
    protected $primaryKey = 'id';
    protected $returnType = 'object';
    protected $allowedFields = ['nama_pengirim','perihal','tgl_kirim','unit_pengirim','unit_penerima','nama_penerima','tgl_terima'];
}

?>